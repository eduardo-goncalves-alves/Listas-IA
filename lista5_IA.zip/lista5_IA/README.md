# Market Basket Analysis - Supermercado

Projeto desenvolvido para a disciplina de Inteligência Artificial.

## Objetivo

Aplicar o algoritmo Apriori para identificar associações entre produtos comprados pelos clientes de um supermercado.

## Dataset

O conjunto de dados contém transações de compras e produtos representados por valores binários (0 e 1).

## Tecnologias Utilizadas

- Python
- Pandas
- Matplotlib
- Seaborn
- Mlxtend

## Etapas

1. Carregamento dos dados
2. Análise exploratória
3. Aplicação do algoritmo Apriori
4. Geração de regras de associação
5. Interpretação dos resultados
