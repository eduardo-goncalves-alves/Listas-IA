-Relatório - Market Basket Analysis

-Abordagem Adotada

Foi utilizada a técnica de Market Basket Analysis através do algoritmo Apriori para identificar padrões de compra entre os produtos do supermercado.

Após a identificação dos conjuntos frequentes, foram geradas regras de associação avaliadas pelas métricas de suporte, confiança e lift.

-Principais Resultados

Os produtos mais frequentes foram pão, leite, arroz, feijão e hortifruti.

As regras com maior lift indicam produtos que costumam ser comprados juntos com frequência superior ao esperado pelo acaso.

-Interpretações de Negócio

As regras encontradas podem ser utilizadas para:

* criar promoções combinadas;
* organizar produtos próximos nas gôndolas;
* sugerir produtos complementares;
* aumentar o ticket médio das compras.

-Respostas às Questões

-Quais produtos apresentam maior associação entre si?

Os produtos com maior valor de lift apresentam as associações mais fortes e relevantes para o negócio.

-Existem produtos que funcionam como âncora para outras compras?

Sim. Produtos de compra recorrente, como pão e leite, tendem a funcionar como produtos âncora, atraindo compras complementares.

-Quais regras possuem maior potencial para ações promocionais?

As regras com altos valores de confiança e lift são as mais indicadas para promoções conjuntas.

-Alguma regra pode ser considerada enganosa?

Sim. Algumas regras podem apresentar alta confiança apenas porque os produtos envolvidos são muito populares, sem representar uma associação real relevante.

-Como os resultados podem impactar o layout do supermercado?

Produtos frequentemente comprados juntos podem ser posicionados próximos uns dos outros, facilitando a compra e aumentando as vendas por associação.
